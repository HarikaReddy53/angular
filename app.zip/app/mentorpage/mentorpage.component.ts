import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorpage',
  templateUrl: './mentorpage.component.html',
  styleUrls: ['./mentorpage.component.css']
})
export class MentorpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
