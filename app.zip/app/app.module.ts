import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MentregComponent } from './mentreg/mentreg.component';
import { AdminregComponent } from './adminreg/adminreg.component';
import { UserregComponent } from './userreg/userreg.component';
import { NavComponent } from './nav/nav.component';
import { PaymentComponent } from './payment/payment.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentuserreqComponent } from './mentuserreq/mentuserreq.component';
import { UserstatusComponent } from './userstatus/userstatus.component';
import { UserpaymentComponent } from './userpayment/userpayment.component';
import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { UserlistComponent } from './userlist/userlist.component';
import { MentorpageComponent } from './mentorpage/mentorpage.component';
import { MentpaypendingComponent } from './mentpaypending/mentpaypending.component';
import { UserpageComponent } from './userpage/userpage.component';
import { MentexpComponent } from './mentexp/mentexp.component';
import { PaymenthistoryComponent } from './paymenthistory/paymenthistory.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MentregComponent,
    AdminregComponent,
    UserregComponent,
    NavComponent,
    PaymentComponent,
    UserprofileComponent,
    AdminpaymentComponent,
    MentorprogressComponent,
    MentuserreqComponent,
    UserstatusComponent,
    UserpaymentComponent,
    MentorlistComponent,
    UserlistComponent,
    MentorpageComponent,
    MentpaypendingComponent,
    UserpageComponent,
    MentexpComponent,
    PaymenthistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
