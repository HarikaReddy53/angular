import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorlist',
  templateUrl: './mentorlist.component.html',
  styleUrls: ['./mentorlist.component.css']
})
export class MentorlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
