import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserregComponent } from './userreg/userreg.component';
import { LoginComponent } from './login/login.component';
import { AdminregComponent } from './adminreg/adminreg.component';
import { MentregComponent } from './mentreg/mentreg.component';
import { PaymentComponent } from './payment/payment.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentuserreqComponent } from './mentuserreq/mentuserreq.component';
import { UserstatusComponent } from './userstatus/userstatus.component';
import { UserpaymentComponent } from './userpayment/userpayment.component';
import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { UserlistComponent } from './userlist/userlist.component';
import { MentorpageComponent } from './mentorpage/mentorpage.component';
import { MentpaypendingComponent } from './mentpaypending/mentpaypending.component';
import { UserpageComponent } from './userpage/userpage.component';
import { MentexpComponent } from './mentexp/mentexp.component';


const routes: Routes = [

{  path:"user", component: UserregComponent},
{  path:"login", component: LoginComponent},
{path:"mentor",component: MentregComponent},
{path:"admin",component: AdminregComponent},
{path:"payment",component:PaymentComponent},
{path:"userprofile",component:UserprofileComponent},
{path:"adminpayment",component:AdminpaymentComponent},
{path:"mentorprogress",component:MentorprogressComponent},
{path:"mentuserreq",component:MentuserreqComponent},
{path:"userstatus",component:UserstatusComponent},
{path:"userpayment",component:UserpaymentComponent},
{path:"mentorlist",component:MentorlistComponent},
{path:"userlist",component:UserlistComponent},
{path:"mentorpage",component:MentorpageComponent},
{path:"mentpaypending",component:MentpaypendingComponent},
{path:"userpage",component:UserpageComponent},
{path:"mentexp",component:MentexpComponent},
{path:"", pathMatch:"full", redirectTo:"login"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
