import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorprogress',
  templateUrl: './mentorprogress.component.html',
  styleUrls: ['./mentorprogress.component.css']
})
export class MentorprogressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
