import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentuserreq',
  templateUrl: './mentuserreq.component.html',
  styleUrls: ['./mentuserreq.component.css']
})
export class MentuserreqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
