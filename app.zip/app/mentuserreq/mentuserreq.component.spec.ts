import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentuserreqComponent } from './mentuserreq.component';

describe('MentuserreqComponent', () => {
  let component: MentuserreqComponent;
  let fixture: ComponentFixture<MentuserreqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentuserreqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentuserreqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
